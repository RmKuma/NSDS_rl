import zmq
import json
import numpy as np
from struct import *


def send_array(socket, A, flags=0, copy=True, track=False):
    """send a numpy array with metadata"""
    md = dict(
        dtype=str(A.dtype),
        shape=A.shape,
    )
    socket.send_json(md, flags | zmq.SNDMORE)
    return socket.send(A, flags, copy=copy, track=track)

class Server():
    def __init__(self, port, obsize):
        self.m_port = port
        self.m_context = zmq.Context()
        self.m_socket = self.m_context.socket(zmq.REP)

        self.m_obsize = obsize
        self.m_socket.bind("tcp://*:5050")

    def _recv(self):
        recv = self.m_socket.recv()
        return recv

    def _communicate(self):
        recv = self._recv()
        dict = json.loads(recv)

        obs = dict["obs"]
        reward = dict["reward"]
        done = dict["done"]
        self.m_socket.send(b"1")
        return obs, reward

    def _obs(self):
        obs = np.zeros((1, self.m_obsize))
        for i in range(self.m_obsize):
            recv = self._recv()
            result = 0
            index = 1
            for byte in recv:
                result = result + int(byte) * index
                index = index * 256

            obs[0][i] = result

            self.m_socket.send(b"1")

        return obs

    def _action(self, action):
        # get signal "action"
        recv = self._recv()
        flags = 0

        md = dict(
            dtype=str(action.dtype),
            shape=action.shape,
            data=action.tolist()
        )

        self.m_socket.send_json(md, flags | zmq.SNDMORE)
        return

    def _reward(self):
        recv = self._recv()
        reward = self.byteToint(recv)

        if reward == 255.0:
            reward = -1.0

        self.m_socket.send(b"1")

        return reward

    def _end(self):
        recv = self._recv()
        end = self.byteToint(recv)
        self.m_socket.send(b"1")

        if end == 1:
            return True

        return False

    def byteToint(self, byte):
        result = int.from_bytes(byte, byteorder='big', signed=True)
        return result

import gym

import numpy as np
from gym import spaces
from socket import *

from environment.server import Server


class NetwEnv(gym.Env):
    metadata = {'render.modes': ['human']}

    def __init__(self, num_of_flows):
        self.server = Server(5050, 3)

        self.num_of_flows = num_of_flows
        self.action_space = spaces.Box(low=-1, high=1, shape=(num_of_flows,), dtype=np.float32)
        self.observation_space = spaces.Box(low=0, high=1, shape=(num_of_flows * 3,), dtype=np.float32)

    def step(self, action):

        # self.server._action (action)
        # print(action)
        # reward = self.server._reward ()
        # print(reward)
        # obs = self.server._obs ()
        # print(obs)
        # done = self.server._end ()
        # print(done)
        self.server._action(action)
        obs, reward, done = self.server._communicate()
        info = {"None": 1}
        # reward = -reward
        # if reward != 0:
        # print(reward)

        return obs, reward, done, info

    def reset(self):
        # obs = np.zeros ((1,3))
        # obs = self.server._obs ()
        # print(obs)
        # dump = self.server._end ()

        obs, reward, done = self.server._communicate()
        return obs

    def render(self):
        pass